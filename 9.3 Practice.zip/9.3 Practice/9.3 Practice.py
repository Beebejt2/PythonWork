#Practice 9.3
#This program will mimic the random messages within a fortune cookie via file

import random

FILENAME = "FortuneCookies.txt"

#Open file for reading
def buildListFromFile(theList):
    datafile = open(FILENAME, "r")
    for inputStrItem in datafile:
        theList.append(inputStrItem)
    datafile.close()
    return theList

#Get a random number
def randomNumber():
    randNum = random.randrange(0,10)
    return randNum

#prompt the user if they want to get another fortune
def continuePrompt():
    prompt = input("Would you like to eat another fortune cookie? (Y/N): ")
    print("-----------------------------------------------------------")
    if prompt == "Y" or prompt == "y":
        return True
    else:
        return False    

fortunes = []
fortunes = buildListFromFile(fortunes)
prompted = True

while prompted:
    print("You eat the fortune cookie...")
    print()
    randNumber = randomNumber()
    #print(randNumber)
    print(fortunes[randNumber])
    prompted = continuePrompt()
print("Goodbye")
print("-----------------------------------------------------------")
